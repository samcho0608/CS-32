#include "Actor.h"
#include "StudentWorld.h"

void TunnelMan::doSomething()
{
	int ch;
	if (getWorld()->getKey(ch) == true)
	{
		int dest;
		// user hit a key this tick!
		getWorld()->deleteEarth(getX(), getY());
		switch (ch)
		{
		case KEY_PRESS_LEFT:
			dest = getX() - 1;
			if (getDirection() == left)
			{
				if (dest >= 0 && dest <= 60)
					moveTo(dest, getY());
				else
					moveTo(getX(), getY());
			}
			else
				setDirection(left);
			break;
		case KEY_PRESS_RIGHT:
			dest = getX() + 1;
			if (getDirection() == right)
			{
				if (dest >= 0 && dest <= 60)
					moveTo(dest, getY());
				else
					moveTo(getX(), getY());
			}
			else
				setDirection(right);
			break;
		case KEY_PRESS_UP:
			dest = getY() + 1;
			if (getDirection() == up)
			{
				if (dest >= 0 && dest <= 60)
					moveTo(getX(), dest);
				else
					moveTo(getX(), getY());
			}
			else
				setDirection(up);
			break;
		case KEY_PRESS_DOWN:
			dest = getY() - 1;
			if (getDirection() == down)
			{
				if (dest >= 0 && dest <= 60)
					moveTo(getX(), dest);
				else
					moveTo(getX(), getY());
			}
			else
				setDirection(down);
			break;
			// etc�
		}
	}
}

// Students:  Add code to this file (if you wish), Actor.h, StudentWorld.h, and StudentWorld.cpp
