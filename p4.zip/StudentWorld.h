#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "Actor.h"
#include "GameWorld.h"
#include "GameConstants.h"
#include <string>
#include <vector>

// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp

class StudentWorld : public GameWorld
{
public:
	StudentWorld(std::string assetDir)
		: GameWorld(assetDir)
	{
	}

	virtual int init();

	virtual int move();

	virtual void cleanUp()
	{
		for (int i = 0; i < 60; i++)
			for (int j = 0; j < 60; j++)
				delete m_earth[i][j];

		std::vector<Actor*>::iterator i = m_actors.begin();
		while( i != m_actors.end())
		{
			Actor* temp = *i;
			i = m_actors.erase(i);
			delete temp;
		}
		delete m_player;
	}

	~StudentWorld()
	{
		cleanUp();
	}

	void deleteEarth(int x, int y);

private:
	Earth* m_earth[VIEW_WIDTH][VIEW_HEIGHT] = {};
	TunnelMan* m_player = nullptr;
	std::vector<Actor*> m_actors;
};

#endif // STUDENTWORLD_H_
