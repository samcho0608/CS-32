#include "StudentWorld.h"
#include <string>
using namespace std;

GameWorld* createStudentWorld(string assetDir)
{
	return new StudentWorld(assetDir);
}

// Students:  Add code to this file (if you wish), StudentWorld.h, Actor.h and Actor.cpp

int StudentWorld::init()
{
	for (int i = 0; i < VIEW_HEIGHT; i++) // row
	{
		for (int j = 0; j < VIEW_WIDTH; j++) // col
		{
			if (i < 60 && (i < 4 || (j < 30 || j > 33)))
				m_earth[j][i] = new Earth(j, i, this);
			else
				m_earth[j][i] = nullptr;
		}
	}
	m_player = new TunnelMan(this);
	return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
	m_player->doSomething();
	// This code is here merely to allow the game to build, run, and terminate after you hit enter a few times.
	// Notice that the return value GWSTATUS_PLAYER_DIED will cause our framework to end the current level.
	return GWSTATUS_CONTINUE_GAME;
	decLives();
	return GWSTATUS_PLAYER_DIED;
}

void StudentWorld::deleteEarth(int x, int y)
{
	for (int i = x; i <= x+3; i++)
	{
		for (int j = y; j <= y+3; j++)
		{
			if (m_earth[i][j] != nullptr)
			{
				playSound(SOUND_DIG);
				delete m_earth[i][j];
				m_earth[i][j] = nullptr;
			}
		}
	}
}