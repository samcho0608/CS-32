#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"

class StudentWorld;
// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp
class Actor : public GraphObject
{
public:
	Actor(int imageID, int startX, int startY, Direction dir, double size, unsigned int depth, 
		StudentWorld* sWorld) : GraphObject(imageID, startX, startY, dir, size, depth), 
		m_world(sWorld) {setVisible(true);}
	~Actor() {}
	virtual void doSomething()=0;
	StudentWorld* getWorld() { return m_world; }
private:
	StudentWorld* m_world;
};

class Earth : public Actor
{
public:
	Earth(int x, int y, StudentWorld* sWorld):Actor(TID_EARTH, x, y, right, 0.25, 3, sWorld) {}
	~Earth() {}
	virtual void doSomething() {}
private:

};

class TunnelMan : public Actor
{
public:
	TunnelMan(StudentWorld* sWorld) :Actor(TID_PLAYER, 30, 60, right, 1.0, 0, sWorld) {}
	~TunnelMan() {}
	virtual void doSomething();
private:
};

#endif // ACTOR_H_
